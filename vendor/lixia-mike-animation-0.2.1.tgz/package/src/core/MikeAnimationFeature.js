import { animationRegistry } from '../registry/AnimationRegistry.js'
import { PlaybackLifecycle } from '../player/PlaybackLifecycle.js'
import { PostureScheduler } from '../scheduler/PostureScheduler.js'
import { AnimationCommandScheduler } from '../scheduler/AnimationCommandScheduler.js'
import { MikeAnimationFeatureError } from './MikeAnimationFeatureError.js'

/**
 * Framework-neutral Mike animation feature.
 *
 * The host supplies an `executor(command)` that starts Three.js playback.
 * Core owns registry admission, posture planning, priority scheduling and
 * lifecycle observation — never raw bone paths or asset guessing.
 */
export function createMikeAnimationFeature({
  executor,
  registry = animationRegistry,
  lifecycle = null,
  postureScheduler = null,
  assetBaseUrl = '',
  assetResolver = null,
  diagnostics = console,
  maxQueue = 20,
  stopExecutor = null,
} = {}) {
  if (typeof executor !== 'function') {
    throw new TypeError('createMikeAnimationFeature requires an executor(command) function')
  }

  const playbackLifecycle = lifecycle ?? new PlaybackLifecycle()
  const posture = postureScheduler ?? new PostureScheduler({ registry })
  const scheduler = new AnimationCommandScheduler({
    registry,
    postureScheduler: posture,
    lifecycle: playbackLifecycle,
    executor,
    stopExecutor,
    maxQueue,
  })
  const gestureScheduler = new AnimationCommandScheduler({
    registry,
    postureScheduler: posture,
    lifecycle: playbackLifecycle,
    executor,
    stopExecutor,
    maxQueue,
  })

  let disposed = false
  let speaking = false
  let lipsyncProvider = null
  let gazeTarget = null
  let postureLifecycleUnsubscribe = playbackLifecycle.subscribe(
    (event) => posture.handlePlaybackEvent(event),
    { emitCurrent: false },
  )

  function assertReady(method) {
    if (disposed) {
      throw new MikeAnimationFeatureError(
        'DISPOSED',
        `Cannot call ${method}() after dispose()`,
      )
    }
  }

  function resolveAssetUrl(mikeAsset, record = null) {
    if (!mikeAsset) return mikeAsset
    if (assetResolver) {
      const resolver =
        typeof assetResolver === 'function'
          ? assetResolver
          : assetResolver.resolveAnimation?.bind(assetResolver)
      if (typeof resolver !== 'function') {
        throw new MikeAnimationFeatureError(
          'INVALID_REQUEST',
          'assetResolver must be a function or expose resolveAnimation(record)',
        )
      }
      return resolver(record, mikeAsset)
    }
    if (!assetBaseUrl) return mikeAsset
    if (/^https?:\/\//i.test(mikeAsset)) return mikeAsset
    const base = assetBaseUrl.endsWith('/') ? assetBaseUrl.slice(0, -1) : assetBaseUrl
    const path = mikeAsset.startsWith('/') ? mikeAsset : `/${mikeAsset}`
    return `${base}${path}`
  }

  async function play(request = {}) {
    assertReady('play')
    if (!request.animationId) {
      throw new MikeAnimationFeatureError(
        'INVALID_REQUEST',
        'play() requires animationId',
        { request },
      )
    }
    return scheduler.schedule({
      animationId: request.animationId,
      priority: request.priority ?? 50,
      mode: request.mode ?? 'replace',
      interruptible: request.interruptible,
      options: {
        repeats: request.repeats,
        loop: request.loop,
        transitionSeconds: request.transitionSeconds,
        layer: request.layer ?? 'full_body',
        assetBaseUrl,
        resolveAssetUrl,
        ...request.options,
      },
    })
  }

  /**
   * Presentation gesture entry. Layered bone masks are Milestone D; today this
   * schedules through the same command path with layer metadata retained for
   * the future mixer.
   */
  async function gesture(request = {}) {
    assertReady('gesture')
    if (!request.animationId) {
      throw new MikeAnimationFeatureError(
        'INVALID_REQUEST',
        'gesture() requires animationId',
        { request },
      )
    }
    return gestureScheduler.schedule({
      animationId: request.animationId,
      priority: request.priority ?? 40,
      mode: request.mode ?? 'replace',
      interruptible: request.interruptible,
      options: {
        repeats: request.repeats,
        loop: request.loop,
        transitionSeconds: request.transitionSeconds,
        layer: request.layer ?? 'upper_body',
        assetBaseUrl,
        resolveAssetUrl,
        ...request.options,
      },
    })
  }

  return {
    play,
    gesture,

    setSpeaking(value) {
      assertReady('setSpeaking')
      speaking = Boolean(value)
      lipsyncProvider?.setSpeaking?.(speaking)
      diagnostics?.info?.(`[mike-animation] speaking=${speaking}`)
      return speaking
    },

    isSpeaking() {
      return speaking
    },

    connectLipsync(provider) {
      assertReady('connectLipsync')
      if (lipsyncProvider && lipsyncProvider !== provider) {
        lipsyncProvider.reset?.()
        lipsyncProvider.dispose?.()
      }
      lipsyncProvider = provider ?? null
      lipsyncProvider?.setSpeaking?.(speaking)
      return lipsyncProvider
    },

    getLipsyncProvider() {
      return lipsyncProvider
    },

    applyLipsync(weights) {
      assertReady('applyLipsync')
      if (typeof lipsyncProvider?.apply !== 'function') {
        throw new MikeAnimationFeatureError(
          'LIPSYNC_NOT_CONNECTED',
          'connectLipsync() requires a provider with apply(weights)',
        )
      }
      lipsyncProvider.apply(weights ?? {})
    },

    resetLipsync() {
      assertReady('resetLipsync')
      lipsyncProvider?.reset?.()
    },

    update(deltaSeconds) {
      assertReady('update')
      const delta = Number(deltaSeconds)
      if (!Number.isFinite(delta) || delta < 0) {
        throw new MikeAnimationFeatureError(
          'INVALID_REQUEST',
          'update(deltaSeconds) requires a non-negative finite number',
        )
      }
      lipsyncProvider?.update?.(delta, { speaking, gazeTarget })
    },

    setGazeTarget(target) {
      assertReady('setGazeTarget')
      gazeTarget = target ?? null
      return gazeTarget
    },

    getGazeTarget() {
      return gazeTarget
    },

    stop(reason = 'stopped') {
      assertReady('stop')
      const fullBody = scheduler.stop(reason)
      const upperBody = gestureScheduler.stop(reason)
      return { full_body: fullBody, upper_body: upperBody }
    },

    cancel(commandId) {
      assertReady('cancel')
      return scheduler.cancel(commandId) || gestureScheduler.cancel(commandId)
    },

    resolve(animationId) {
      return registry.resolve(animationId)
    },

    requirePlayable(animationId, options) {
      return registry.playable(animationId, options)
    },

    getPlaybackState() {
      return playbackLifecycle.current
    },

    subscribePlayback(listener, options) {
      return playbackLifecycle.subscribe(listener, options)
    },

    getPostureState() {
      return posture.current
    },

    planPosture(animationId) {
      return posture.plan(registry.playable(animationId))
    },

    subscribePosture(listener, options) {
      return posture.subscribe(listener, options)
    },

    getSchedulerState() {
      return scheduler.snapshot
    },

    getLayerSchedulerState() {
      return Object.freeze({
        full_body: scheduler.snapshot,
        upper_body: gestureScheduler.snapshot,
      })
    },

    subscribeScheduler(listener, options) {
      return scheduler.subscribe(listener, options)
    },

    subscribeLayerSchedulers(listener, options = {}) {
      const fullBodyUnsubscribe = scheduler.subscribe(
        (event) => listener({ layer: 'full_body', event }),
        options,
      )
      const upperBodyUnsubscribe = gestureScheduler.subscribe(
        (event) => listener({ layer: 'upper_body', event }),
        options,
      )
      return () => {
        fullBodyUnsubscribe()
        upperBodyUnsubscribe()
      }
    },

    resolveAssetUrl,

    get assetBaseUrl() {
      return assetBaseUrl
    },

    get assetResolver() {
      return assetResolver
    },

    /** Compatibility accessors for the current viewer bridge. */
    get lifecycle() {
      return playbackLifecycle
    },

    get postureScheduler() {
      return posture
    },

    get commandScheduler() {
      return scheduler
    },

    get registry() {
      return registry
    },

    dispose() {
      if (disposed) return
      disposed = true
      postureLifecycleUnsubscribe?.()
      postureLifecycleUnsubscribe = null
      scheduler.dispose()
      gestureScheduler.dispose()
      playbackLifecycle.dispose()
      lipsyncProvider?.dispose?.()
      lipsyncProvider = null
      gazeTarget = null
    },
  }
}
