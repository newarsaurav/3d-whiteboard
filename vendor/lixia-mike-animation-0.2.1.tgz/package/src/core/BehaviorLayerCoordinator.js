export const BODY_LAYERS = Object.freeze({
  FULL_BODY: 'full_body',
  LOCOMOTION: 'locomotion',
  UPPER_BODY: 'upper_body',
  GAZE: 'gaze',
  FACE: 'face',
})

const VALID_LAYERS = new Set(Object.values(BODY_LAYERS))
const CONFLICTS = Object.freeze({
  [BODY_LAYERS.FULL_BODY]: new Set([
    BODY_LAYERS.FULL_BODY,
    BODY_LAYERS.LOCOMOTION,
  ]),
  [BODY_LAYERS.LOCOMOTION]: new Set([
    BODY_LAYERS.FULL_BODY,
    BODY_LAYERS.LOCOMOTION,
  ]),
  [BODY_LAYERS.UPPER_BODY]: new Set([
    BODY_LAYERS.UPPER_BODY,
  ]),
  [BODY_LAYERS.GAZE]: new Set([BODY_LAYERS.GAZE]),
  [BODY_LAYERS.FACE]: new Set([BODY_LAYERS.FACE]),
})

/**
 * Deterministic ownership for independently updated parts of Mike's body.
 * It does not move bones; it decides whether a behavior is allowed to own a
 * layer, so planners cannot create incompatible simultaneous actions.
 */
export class BehaviorLayerCoordinator {
  constructor() {
    this.claims = new Map()
    this.listeners = new Set()
  }

  claim({ actionId, layer, priority = 50, interruptible = true } = {}) {
    if (!actionId) throw new TypeError('Layer claims require actionId')
    if (!VALID_LAYERS.has(layer)) throw new TypeError(`Unknown body layer: ${layer}`)
    const numericPriority = Number(priority)
    if (!Number.isFinite(numericPriority) || numericPriority < 0 || numericPriority > 100) {
      throw new TypeError('Layer priority must be between 0 and 100')
    }

    const blockers = []
    const preempted = []
    for (const active of this.claims.values()) {
      if (!CONFLICTS[layer].has(active.layer)) continue
      if (!active.interruptible || active.priority > numericPriority) blockers.push(active)
      else preempted.push(active)
    }
    if (blockers.length) {
      return Object.freeze({
        accepted: false,
        reason: 'layer_busy',
        blockers: blockers.map((claim) => ({ ...claim })),
        preempted: [],
      })
    }

    preempted.forEach((claim) => this.claims.delete(claim.layer))
    const next = Object.freeze({
      actionId,
      layer,
      priority: numericPriority,
      interruptible: Boolean(interruptible),
    })
    this.claims.set(layer, next)
    this.#publish('claimed', next, { preempted })
    return Object.freeze({
      accepted: true,
      claim: next,
      blockers: [],
      preempted: preempted.map((claim) => ({ ...claim })),
    })
  }

  release(actionId, reason = 'completed') {
    let released = null
    for (const [layer, claim] of this.claims) {
      if (claim.actionId !== actionId) continue
      this.claims.delete(layer)
      released = claim
      break
    }
    if (released) this.#publish('released', released, { reason })
    return Boolean(released)
  }

  clear(reason = 'cleared') {
    const released = [...this.claims.values()]
    this.claims.clear()
    released.forEach((claim) => this.#publish('released', claim, { reason }))
    return released.length
  }

  subscribe(listener, { emitCurrent = true } = {}) {
    if (typeof listener !== 'function') throw new TypeError('Layer listener must be a function')
    this.listeners.add(listener)
    if (emitCurrent) listener({ type: 'snapshot', snapshot: this.snapshot })
    return () => this.listeners.delete(listener)
  }

  get snapshot() {
    return Object.freeze(Object.fromEntries(
      [...this.claims].map(([layer, claim]) => [layer, { ...claim }]),
    ))
  }

  #publish(type, claim, detail = {}) {
    const event = Object.freeze({ type, claim: { ...claim }, ...detail, snapshot: this.snapshot })
    for (const listener of this.listeners) listener(event)
  }
}
