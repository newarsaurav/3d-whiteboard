import { BehaviorLayerCoordinator, BODY_LAYERS } from './BehaviorLayerCoordinator.js'

export const EMBODIED_ACTION_TYPES = Object.freeze([
  'play_animation',
  'gesture',
  'idle',
  'stop',
  'walk_to',
  'turn_to',
  'look_at',
  'point_to',
  'follow_user',
])

const WORLD_ACTIONS = new Set(['walk_to', 'turn_to', 'point_to', 'follow_user'])
const TARGET_ACTIONS = new Set(['walk_to', 'turn_to', 'look_at', 'point_to'])

export class EmbodiedActionError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'EmbodiedActionError'
    this.code = code
    this.details = details
  }
}

/**
 * Safe boundary between an AI/backend plan and Mike's deterministic runtime.
 * World actions are delegated to the host; body animation remains registry-ID
 * based. Facial animation and TTS deliberately stay outside this controller.
 */
export function createEmbodiedActionController({
  animationFeature,
  worldExecutor = null,
  validateWorldAction = null,
  layers = new BehaviorLayerCoordinator(),
} = {}) {
  if (!animationFeature) throw new TypeError('Embodied actions require animationFeature')
  let sequence = 0

  function normalize(request = {}) {
    if (!EMBODIED_ACTION_TYPES.includes(request.type)) {
      throw new EmbodiedActionError(
        'ACTION_NOT_PERMITTED',
        `Unsupported embodied action: ${request.type ?? '(missing)'}`,
      )
    }
    if (TARGET_ACTIONS.has(request.type) && request.target == null) {
      throw new EmbodiedActionError('TARGET_REQUIRED', `${request.type} requires target`)
    }
    if (['play_animation', 'gesture'].includes(request.type) && !request.animationId) {
      throw new EmbodiedActionError(
        'ANIMATION_REQUIRED',
        `${request.type} requires a registered animationId`,
      )
    }
    sequence += 1
    return Object.freeze({
      ...request,
      actionId: request.actionId ?? `embodied-action-${sequence}`,
      priority: Number(request.priority ?? 50),
      interruptible: request.interruptible ?? true,
    })
  }

  function result(action, status, detail = {}) {
    return Object.freeze({
      action_id: action.actionId,
      type: action.type,
      status,
      ...detail,
    })
  }

  async function execute(input) {
    const action = normalize(input)

    if (action.type === 'stop' || action.type === 'idle') {
      const stopResult = animationFeature.stop(action.type)
      layers.clear(action.type)
      return result(action, 'succeeded', { result: stopResult })
    }

    if (action.type === 'look_at') {
      const claim = layers.claim({ ...action, layer: BODY_LAYERS.GAZE })
      if (!claim.accepted) return result(action, 'failed', { reason: claim.reason })
      animationFeature.setGazeTarget(action.target)
      return result(action, 'started', { layer: BODY_LAYERS.GAZE })
    }

    if (WORLD_ACTIONS.has(action.type)) {
      if (typeof worldExecutor !== 'function') {
        return result(action, 'failed', { reason: 'world_executor_unavailable' })
      }
      const validation = await validateWorldAction?.(action)
      if (validation === false || validation?.ok === false) {
        return result(action, 'failed', {
          reason: validation?.reason ?? 'world_validation_failed',
        })
      }
      const layer = action.type === 'walk_to' || action.type === 'follow_user'
        ? BODY_LAYERS.LOCOMOTION
        : action.type === 'point_to'
          ? BODY_LAYERS.UPPER_BODY
          : BODY_LAYERS.FULL_BODY
      const claim = layers.claim({ ...action, layer })
      if (!claim.accepted) return result(action, 'failed', { reason: claim.reason })
      try {
        const hostResult = await worldExecutor(action)
        if (hostResult?.status === 'failed') {
          layers.release(action.actionId, 'failed')
          return result(action, 'failed', { reason: hostResult.reason ?? 'host_failed' })
        }
        return result(action, hostResult?.status ?? 'started', { layer, result: hostResult })
      } catch (error) {
        layers.release(action.actionId, 'failed')
        return result(action, 'failed', { reason: 'host_error', message: error.message })
      }
    }

    const layer = action.type === 'gesture' ? BODY_LAYERS.UPPER_BODY : BODY_LAYERS.FULL_BODY
    const claim = layers.claim({ ...action, layer })
    if (!claim.accepted) return result(action, 'failed', { reason: claim.reason })
    try {
      const playback = action.type === 'gesture'
        ? await animationFeature.gesture({ ...action, layer })
        : await animationFeature.play({ ...action, layer })
      if (!playback?.accepted) {
        layers.release(action.actionId, 'failed_to_start')
        return result(action, 'failed', { reason: 'animation_failed_to_start' })
      }
      return result(action, playback.queued ? 'accepted' : 'started', {
        layer,
        command_id: playback.command_id,
      })
    } catch (error) {
      layers.release(action.actionId, 'failed_to_start')
      return result(action, 'failed', {
        reason: error.code ?? 'animation_error',
        message: error.message,
      })
    }
  }

  return Object.freeze({
    execute,
    complete(actionId, status = 'succeeded') {
      if (!['succeeded', 'failed', 'interrupted', 'cancelled'].includes(status)) {
        throw new EmbodiedActionError('INVALID_STATUS', `Unknown completion status: ${status}`)
      }
      return layers.release(actionId, status)
    },
    getLayerState: () => layers.snapshot,
    subscribeLayers: (listener, options) => layers.subscribe(listener, options),
    layers,
  })
}

