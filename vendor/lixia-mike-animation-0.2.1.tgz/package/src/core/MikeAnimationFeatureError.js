export class MikeAnimationFeatureError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'MikeAnimationFeatureError'
    this.code = code
    this.details = details
  }
}
