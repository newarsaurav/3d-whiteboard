const DEFAULT_OPTIONS = Object.freeze({
  wordsPerSecond: 2.6,
  minBeatMs: 1400,
  maxBeatMs: 5000,
  gapMs: 120,
})

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value))
}

export function estimateBeatDuration(text, options = {}) {
  const settings = { ...DEFAULT_OPTIONS, ...options }
  const words = String(text ?? '').trim().split(/\s+/).filter(Boolean).length
  const spokenMs = (Math.max(1, words) / settings.wordsPerSecond) * 1000
  return Math.round(clamp(spokenMs, settings.minBeatMs, settings.maxBeatMs))
}

/**
 * Turns short spoken segments into deterministic, timed animation plans.
 * The language model selects intents; PresentationDirector still selects clips.
 */
export function buildPresentationTimeline(segments, director, options = {}) {
  const settings = { ...DEFAULT_OPTIONS, ...options }
  const source = Array.isArray(segments) ? segments.slice(0, 8) : []
  let offsetMs = 0

  const beats = source
    .map((segment, index) => {
      const text = String(segment?.text ?? '').trim()
      if (!text) return null

      let plan
      try {
        plan = director.resolve({ gesture: segment?.gesture ?? 'continue' })
      } catch {
        plan = director.resolve({ gesture: 'continue' })
      }

      const durationMs = estimateBeatDuration(text, settings)
      const beat = Object.freeze({
        index,
        text,
        gesture: plan.gesture,
        offset_ms: offsetMs,
        duration_ms: durationMs,
        mode: plan.mode,
        animation_id: plan.animation_id,
        record: plan.record,
      })
      offsetMs += durationMs + settings.gapMs
      return beat
    })
    .filter(Boolean)

  return Object.freeze({
    reply: beats.map((beat) => beat.text).join(' '),
    duration_ms: beats.length ? offsetMs - settings.gapMs : 0,
    beats: Object.freeze(beats),
  })
}

/**
 * Cancellable timer bridge.
 *
 * Two driving modes:
 * - auto (default): beats fire on their estimated `offset_ms` timers.
 * - manual (`autoAdvance: false`): no timers are scheduled; the host — for
 *   example a TTS provider emitting word/sentence boundaries — calls
 *   `advanceTo(index)` to fire each beat at the exact spoken moment.
 * Calling advanceTo() in auto mode also cancels the remaining timers and
 * hands control to the caller, so a TTS integration can take over mid-reply.
 */
export class PresentationTimelinePlayer {
  constructor({ setTimer, clearTimer } = {}) {
    // Browser timer functions require their global receiver in some runtimes.
    // Wrapping them avoids `Illegal invocation` when stored as class fields.
    this.setTimer = setTimer ?? ((callback, delay) => globalThis.setTimeout(callback, delay))
    this.clearTimer = clearTimer ?? ((timer) => globalThis.clearTimeout(timer))
    this.timers = []
    this.generation = 0
    this.timeline = null
    this.onBeat = null
  }

  play(timeline, onBeat, { autoAdvance = true } = {}) {
    this.cancel()
    this.timeline = timeline
    this.onBeat = onBeat
    if (!autoAdvance) return () => this.cancel()
    const generation = this.generation
    for (const beat of timeline?.beats ?? []) {
      const timer = this.setTimer(() => {
        if (generation === this.generation) onBeat(beat)
      }, Math.max(0, beat.offset_ms ?? 0))
      this.timers.push(timer)
    }
    return () => this.cancel()
  }

  advanceTo(index) {
    const beat = this.timeline?.beats?.[index]
    if (!beat || !this.onBeat) return
    for (const timer of this.timers) this.clearTimer(timer)
    this.timers = []
    this.generation += 1
    this.onBeat(beat)
  }

  cancel() {
    for (const timer of this.timers) this.clearTimer(timer)
    this.timers = []
    this.generation += 1
  }
}
