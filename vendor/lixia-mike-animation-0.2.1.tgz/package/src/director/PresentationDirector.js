import gestureDocument from '../../config/presentation-gestures.json' with { type: 'json' }
import { animationRegistry } from '../registry/AnimationRegistry.js'
import { buildPresentationTimeline } from './PresentationTimeline.js'

export class PresentationDirectorError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'PresentationDirectorError'
    this.code = code
    this.details = details
  }
}

/**
 * Deterministic presentation director.
 * The LLM may propose an intent; this class alone admits an approved Mike clip.
 */
export class PresentationDirector {
  constructor({
    registry = animationRegistry,
    catalog = gestureDocument,
    strictApproved = true,
  } = {}) {
    this.registry = registry
    this.catalog = catalog
    this.strictApproved = strictApproved
    this.byIntent = new Map()
    for (const gesture of catalog.gestures || []) {
      this.byIntent.set(gesture.intent, Object.freeze({ ...gesture }))
    }
  }

  listGestures() {
    return [...this.byIntent.values()]
  }

  formatCatalogForPrompt() {
    return this.listGestures()
      .map((gesture) => {
        const target = gesture.animation_id ?? 'null'
        return `- ${gesture.intent}: ${gesture.description} -> ${target}`
      })
      .join('\n')
  }

  /**
   * Resolve LLM output into a playable plan.
   * Accepts intent names, approved registry ids, or numeric Mixamo source ids.
   */
  resolve(request = {}) {
    const intentRaw = request.gesture ?? request.intent ?? null
    const idRaw = request.animationId ?? request.animation_id ?? null

    let intent = typeof intentRaw === 'string' ? intentRaw.trim().toLowerCase() : null
    if (intent === '' || intent === 'null' || intent === 'none') intent = null

    if (intent && this.byIntent.has(intent)) {
      const gesture = this.byIntent.get(intent)
      if (!gesture.animation_id || intent === 'continue') {
        return Object.freeze({
          ok: true,
          mode: 'continue',
          gesture: intent,
          animation_id: null,
          record: null,
          reason: 'no_new_gesture',
        })
      }
      const record = this.#requireApproved(gesture.animation_id)
      if (intent === 'idle') {
        return Object.freeze({
          ok: true,
          mode: 'idle',
          gesture: intent,
          animation_id: record.id,
          record,
          reason: 'idle',
        })
      }
      return Object.freeze({
        ok: true,
        mode: 'play',
        gesture: intent,
        animation_id: record.id,
        record,
        reason: 'intent_map',
      })
    }

    if (idRaw) {
      const record = this.#requireApproved(idRaw)
      const matchedIntent = this.listGestures().find((item) => item.animation_id === record.id)
      return Object.freeze({
        ok: true,
        mode: 'play',
        gesture: matchedIntent?.intent ?? null,
        animation_id: record.id,
        record,
        reason: 'approved_id',
      })
    }

    if (intent) {
      throw new PresentationDirectorError(
        'UNKNOWN_GESTURE',
        `Gesture intent is not in the presentation vocabulary: ${intent}`,
        { gesture: intent },
      )
    }

    return Object.freeze({
      ok: true,
      mode: 'continue',
      gesture: this.catalog.default_gesture ?? 'continue',
      animation_id: null,
      record: null,
      reason: 'default_continue',
    })
  }

  resolveTimeline(segments, options = {}) {
    return buildPresentationTimeline(segments, this, options)
  }

  alternatives(excludeAnimationId, limit = 5) {
    return this.listGestures()
      .filter((gesture) => gesture.animation_id && gesture.animation_id !== excludeAnimationId)
      .slice(0, limit)
      .map((gesture) => {
        const record = this.registry.resolve(gesture.animation_id)
        return {
          intent: gesture.intent,
          id: gesture.animation_id,
          action: record?.name ?? gesture.label,
          source: 'director',
        }
      })
  }

  #requireApproved(idOrAlias) {
    const record = this.strictApproved
      ? this.registry.playable(idOrAlias, { strict: true })
      : this.registry.playable(idOrAlias)
    if (record.presentation_safe === false) {
      throw new PresentationDirectorError(
        'NOT_PRESENTATION_SAFE',
        `Animation ${record.id} is not presentation-safe`,
        { animation_id: record.id },
      )
    }
    return record
  }
}

export const presentationDirector = new PresentationDirector()
