import registryDocument from '../../registry/animations.json' with { type: 'json' }
import policy from '../../config/animation-policy.json' with { type: 'json' }

const REQUIRED_FIELDS = [
  'id',
  'source_id',
  'name',
  'character_id',
  'source_type',
  'mike_asset',
  'quality_status',
  'enabled',
]

export class AnimationRegistryError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'AnimationRegistryError'
    this.code = code
    this.details = details
  }
}

export class AnimationRegistry {
  constructor(document, runtimePolicy = policy) {
    if (document?.character_id !== 'mike' || !Array.isArray(document?.animations)) {
      throw new AnimationRegistryError('INVALID_DOCUMENT', 'Registry must contain Mike animations')
    }

    this.document = document
    this.policy = runtimePolicy
    this.byId = new Map()
    this.byAlias = new Map()

    for (const record of document.animations) {
      const missing = REQUIRED_FIELDS.filter((field) => record[field] === undefined)
      if (missing.length) {
        throw new AnimationRegistryError(
          'INVALID_RECORD',
          `Animation ${record.id ?? '<unknown>'} is missing: ${missing.join(', ')}`,
          { record },
        )
      }
      if (this.byId.has(record.id)) {
        throw new AnimationRegistryError('DUPLICATE_ID', `Duplicate animation ID: ${record.id}`)
      }
      this.byId.set(record.id, Object.freeze({ ...record }))
      this.byAlias.set(record.source_id, record.id)
      this.byAlias.set(`${record.source_type}:${record.source_id}`, record.id)
    }
  }

  resolve(idOrAlias) {
    if (!idOrAlias) return null
    const key = String(idOrAlias)
    const id = this.byId.has(key) ? key : this.byAlias.get(key)
    return id ? this.byId.get(id) ?? null : null
  }

  require(idOrAlias) {
    const record = this.resolve(idOrAlias)
    if (!record) {
      throw new AnimationRegistryError(
        'ANIMATION_NOT_FOUND',
        `Animation is not registered: ${idOrAlias}`,
      )
    }
    return record
  }

  playable(idOrAlias, { strict = false } = {}) {
    const record = this.require(idOrAlias)
    const allowed = strict
      ? [this.policy.runtime.strict_production_status]
      : this.policy.runtime.allowed_quality_statuses
    if (!record.enabled || !allowed.includes(record.quality_status)) {
      throw new AnimationRegistryError(
        'ANIMATION_NOT_ADMITTED',
        `Animation ${record.id} is not admitted by the current runtime policy`,
        { enabled: record.enabled, quality_status: record.quality_status, strict },
      )
    }
    return record
  }

  list(filters = {}) {
    return [...this.byId.values()].filter((record) =>
      Object.entries(filters).every(([key, value]) => {
        if (value === undefined) return true
        if (Array.isArray(record[key])) return record[key].includes(value)
        return record[key] === value
      }),
    )
  }

  get fallback() {
    return this.require(this.policy.fallback_animation_id)
  }
}

export const animationRegistry = new AnimationRegistry(registryDocument, policy)

