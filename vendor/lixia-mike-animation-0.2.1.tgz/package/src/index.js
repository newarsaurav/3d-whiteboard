/**
 * Public surface of the Mike animation feature.
 *
 * Hosts should import from this package entry point, not from deep
 * player/scheduler paths. Deep exports below remain available for the current
 * viewer bridge and focused unit tests.
 */

export { createMikeAnimationFeature } from './core/MikeAnimationFeature.js'
export { MikeAnimationFeatureError } from './core/MikeAnimationFeatureError.js'
export { createThreeMikeExecutor } from './adapters/three/MikeAnimationAdapter.js'

export {
  BehaviorLayerCoordinator,
  BODY_LAYERS,
} from './core/BehaviorLayerCoordinator.js'

export {
  createEmbodiedActionController,
  EmbodiedActionError,
  EMBODIED_ACTION_TYPES,
} from './core/EmbodiedActionController.js'

export {
  createVersionedAssetResolver,
  DEFAULT_CHARACTER_FILE,
} from './assets/AssetUrlResolver.js'

export {
  AnimationRegistry,
  AnimationRegistryError,
  animationRegistry,
} from './registry/AnimationRegistry.js'

export {
  AnimationClipCache,
  animationClipCache,
} from './player/AnimationClipCache.js'

export {
  PlaybackLifecycle,
  PLAYBACK_STATES,
} from './player/PlaybackLifecycle.js'

export { createPlaybackQueue } from './player/PlaybackQueue.js'

export {
  PostureScheduler,
  PostureSchedulerError,
} from './scheduler/PostureScheduler.js'

export {
  AnimationCommandScheduler,
  AnimationCommandSchedulerError,
} from './scheduler/AnimationCommandScheduler.js'

export {
  PresentationDirector,
  PresentationDirectorError,
  presentationDirector,
} from './director/PresentationDirector.js'

export {
  buildPresentationTimeline,
  estimateBeatDuration,
  PresentationTimelinePlayer,
} from './director/PresentationTimeline.js'
