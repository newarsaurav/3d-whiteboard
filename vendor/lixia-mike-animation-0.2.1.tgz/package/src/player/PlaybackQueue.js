import * as THREE from 'three'
import { PLAYBACK_STATES } from './PlaybackLifecycle.js'

function startAction(mixer, actionsMap, currentRef, next, fadeSeconds = 0.25, onActionRetired) {
  const previous = currentRef.current

  // Retire actions older than the outgoing/current pair. The previous action
  // must remain live until Three.js has blended its pose into `next`.
  Object.entries(actionsMap).forEach(([name, action]) => {
    if (action === previous || action === next) return
    action.stop()
    action.enabled = false
    action.setEffectiveWeight(0)
    onActionRetired?.({ name, action })
  })

  next.enabled = true
  next.setEffectiveWeight(1)
  next.setEffectiveTimeScale(1)
  next.reset()
  next.play()

  const fade = Math.max(0, Number(fadeSeconds) || 0)
  if (previous && previous !== next) {
    previous.enabled = true
    if (fade > 0) {
      next.crossFadeFrom(previous, fade, false)
    } else {
      previous.stop()
      previous.enabled = false
      previous.setEffectiveWeight(0)
      const previousEntry = Object.entries(actionsMap).find(([, action]) => action === previous)
      if (previousEntry) onActionRetired?.({ name: previousEntry[0], action: previous })
    }
  }
  currentRef.current = next
}

function resolveRepeats(item) {
  if (typeof item.repeats === 'number' && item.repeats > 0) return item.repeats
  if (item.loop === true) return Infinity
  if (item.loop === false) return 1
  return 1
}

export function createPlaybackQueue({
  mixer,
  actionsRef,
  currentRef,
  lifecycle,
  layer = 'full_body',
  fallbackActionName = 'waiting',
  fadeOutWhenEmpty = false,
  onActionStart,
  onActionRetired,
}) {
  const queue = []
  let busy = false
  let currentItem = null
  let finishedHandler = null
  let elapsedSeconds = 0
  let transitionReady = false

  function clearFinished() {
    if (finishedHandler) {
      mixer.removeEventListener('finished', finishedHandler)
      finishedHandler = null
    }
  }

  function emitPlaying(item, repeats) {
    lifecycle?.transition(PLAYBACK_STATES.PLAYING, {
      animation_id: item.animationId ?? null,
      action_name: item.name,
      layer,
      repeats: Number.isFinite(repeats) ? repeats : null,
    })
  }

  function playNext() {
    clearFinished()

    if (queue.length === 0) {
      busy = false
      currentItem = null
      const waiting = fallbackActionName ? actionsRef.current[fallbackActionName] : null
      if (waiting) {
        waiting.setLoop(THREE.LoopRepeat, Infinity)
        waiting.clampWhenFinished = false
        startAction(
          mixer,
          actionsRef.current,
          currentRef,
          waiting,
          0.35,
          onActionRetired,
        )
        mixer.update(0)
        onActionStart?.({ name: fallbackActionName, animationId: 'mixamo_1094', layer })
        lifecycle?.transition(PLAYBACK_STATES.IDLE, {
          animation_id: 'mixamo_1094',
          action_name: fallbackActionName,
          layer,
        })
      } else {
        const retired = currentRef.current
        if (retired) {
          const retiredEntry = Object.entries(actionsRef.current)
            .find(([, action]) => action === retired)
          retired.stop()
          retired.enabled = false
          retired.setEffectiveWeight(0)
          if (retiredEntry) onActionRetired?.({ name: retiredEntry[0], action: retired })
          currentRef.current = null
        }
        lifecycle?.transition(PLAYBACK_STATES.READY, { layer })
      }
      return
    }

    busy = true
    const item = queue.shift()
    const action = actionsRef.current[item.name]
    if (!action) {
      lifecycle?.transition(PLAYBACK_STATES.ERROR, {
        animation_id: item.animationId ?? null,
        action_name: item.name,
        layer,
        error_code: 'ACTION_NOT_PREPARED',
      })
      playNext()
      return
    }

    currentItem = item
    elapsedSeconds = 0
    transitionReady = false
    const repeats = resolveRepeats(item)

    if (!Number.isFinite(repeats)) {
      action.setLoop(THREE.LoopRepeat, Infinity)
      action.clampWhenFinished = false
      startAction(
        mixer,
        actionsRef.current,
        currentRef,
        action,
        item.fade,
        onActionRetired,
      )
      mixer.update(0)
      onActionStart?.(item)
      emitPlaying(item, repeats)
      return
    }

    action.setLoop(repeats <= 1 ? THREE.LoopOnce : THREE.LoopRepeat, repeats)
    action.clampWhenFinished = true
    startAction(
      mixer,
      actionsRef.current,
      currentRef,
      action,
      item.fade,
      onActionRetired,
    )
    mixer.update(0)
    onActionStart?.(item)
    emitPlaying(item, repeats)

    finishedHandler = (event) => {
      if (event.action !== action) return
      clearFinished()
      lifecycle?.transition(PLAYBACK_STATES.COMPLETED, {
        animation_id: item.animationId ?? null,
        action_name: item.name,
        layer,
      })
      currentItem = null
      playNext()
    }
    mixer.addEventListener('finished', finishedHandler)
  }

  function clear({ emitInterrupted = false, reason = 'replaced' } = {}) {
    if (emitInterrupted && currentItem) {
      lifecycle?.transition(PLAYBACK_STATES.INTERRUPTED, {
        animation_id: currentItem.animationId ?? null,
        action_name: currentItem.name,
        layer,
        reason,
      })
    }
    queue.length = 0
    clearFinished()
    busy = false
    currentItem = null
    elapsedSeconds = 0
    transitionReady = false
  }

  function update(deltaSeconds) {
    if (!currentItem || transitionReady) return
    const action = actionsRef.current[currentItem.name]
    const repeats = resolveRepeats(currentItem)
    if (!action || !Number.isFinite(repeats)) return

    const duration = Number(action.getClip?.()?.duration)
    const delta = Number(deltaSeconds)
    if (!Number.isFinite(duration) || duration <= 0 || !Number.isFinite(delta) || delta < 0) return

    elapsedSeconds += delta
    const lead = Math.min(
      duration * repeats,
      Math.max(0, Number(currentItem.transitionLeadSeconds ?? currentItem.fade ?? 0.25) || 0),
    )
    const remaining = duration * repeats - elapsedSeconds
    if (remaining > lead) return

    transitionReady = true
    lifecycle?.transition(PLAYBACK_STATES.TRANSITION_READY, {
      animation_id: currentItem.animationId ?? null,
      action_name: currentItem.name,
      layer,
      remaining_seconds: Math.max(0, remaining),
      transition_seconds: lead,
    })

    if (queue.length === 0 && fadeOutWhenEmpty && lead > 0) {
      action.fadeOut?.(lead)
    }

    // Sequences prepared directly in this queue can hand off immediately.
    // Scheduler-backed sequences react to the lifecycle event and load their
    // next command while the outgoing pose is still available for blending.
    if (queue.length > 0) {
      lifecycle?.transition(PLAYBACK_STATES.COMPLETED, {
        animation_id: currentItem.animationId ?? null,
        action_name: currentItem.name,
        layer,
        transitioned_early: true,
      })
      currentItem = null
      playNext()
    }
  }

  return {
    enqueue(items) {
      queue.push(...items)
      if (!busy) playNext()
    },
    update,
    clear,
    playNow(items) {
      const seamlessHandoff = Boolean(items[0]?.seamlessHandoff)
      clear({
        emitInterrupted:
          !seamlessHandoff && lifecycle?.current?.state !== PLAYBACK_STATES.TRANSITION_READY,
        reason: seamlessHandoff || lifecycle?.current?.state === PLAYBACK_STATES.TRANSITION_READY
          ? 'seamless_handoff'
          : 'replaced',
      })
      this.enqueue(items)
    },
    returnToWaiting() {
      if (!fallbackActionName) {
        clear({ emitInterrupted: true, reason: 'return_to_base' })
        return
      }
      this.playNow([{
        name: fallbackActionName,
        animationId: 'mixamo_1094',
        repeats: Infinity,
        fade: 0.35,
      }])
    },
    get current() {
      return currentItem ? { ...currentItem } : null
    },
    get pending() {
      return queue.map((item) => ({ ...item }))
    },
  }
}
