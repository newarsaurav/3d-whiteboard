import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js'
import policy from '../../config/animation-policy.json' with { type: 'json' }

export class AnimationClipCache {
  constructor({ maxClips = 24, loaderFactory = () => new FBXLoader() } = {}) {
    this.maxClips = maxClips
    this.loaderFactory = loaderFactory
    this.entries = new Map()
    this.clock = 0
  }

  async load(url) {
    if (!url) throw new Error('Animation URL is required')
    const existing = this.entries.get(url)
    if (existing) {
      existing.lastUsed = ++this.clock
      return existing.promise
    }

    const entry = {
      lastUsed: ++this.clock,
      promise: this.#loadClip(url),
    }
    this.entries.set(url, entry)

    try {
      const clip = await entry.promise
      this.#evict()
      return clip
    } catch (error) {
      this.entries.delete(url)
      throw error
    }
  }

  preload(urls) {
    return Promise.allSettled(urls.map((url) => this.load(url)))
  }

  has(url) {
    return this.entries.has(url)
  }

  clear() {
    this.entries.clear()
  }

  get size() {
    return this.entries.size
  }

  #loadClip(url) {
    const loader = this.loaderFactory()
    return new Promise((resolve, reject) => {
      loader.load(
        url,
        (fbx) => {
          const clip = fbx.animations?.[0]
          if (!clip?.tracks?.length) {
            reject(new Error(`Animation has no playable tracks: ${url}`))
            return
          }
          resolve(clip)
        },
        undefined,
        reject,
      )
    })
  }

  #evict() {
    while (this.entries.size > this.maxClips) {
      let oldestUrl = null
      let oldestUse = Infinity
      for (const [url, entry] of this.entries) {
        if (entry.lastUsed < oldestUse) {
          oldestUse = entry.lastUsed
          oldestUrl = url
        }
      }
      if (!oldestUrl) break
      this.entries.delete(oldestUrl)
    }
  }
}

export const animationClipCache = new AnimationClipCache({
  maxClips: policy.cache.max_clips,
})
