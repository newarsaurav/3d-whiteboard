export const PLAYBACK_STATES = Object.freeze({
  INITIALIZING: 'initializing',
  READY: 'ready',
  LOADING: 'loading',
  PLAYING: 'playing',
  TRANSITION_READY: 'transition_ready',
  COMPLETED: 'completed',
  INTERRUPTED: 'interrupted',
  IDLE: 'idle',
  ERROR: 'error',
  STOPPED: 'stopped',
})

export class PlaybackLifecycle {
  constructor() {
    this.listeners = new Set()
    this.snapshot = Object.freeze({
      state: PLAYBACK_STATES.INITIALIZING,
      sequence: 0,
      changed_at: new Date().toISOString(),
    })
  }

  transition(state, detail = {}) {
    this.snapshot = Object.freeze({
      state,
      sequence: this.snapshot.sequence + 1,
      changed_at: new Date().toISOString(),
      ...detail,
    })
    for (const listener of this.listeners) {
      try {
        listener(this.snapshot)
      } catch (error) {
        console.warn('[animation:lifecycle] listener failed:', error)
      }
    }
    return this.snapshot
  }

  subscribe(listener, { emitCurrent = true } = {}) {
    if (typeof listener !== 'function') throw new TypeError('Playback listener must be a function')
    this.listeners.add(listener)
    if (emitCurrent) listener(this.snapshot)
    return () => this.listeners.delete(listener)
  }

  get current() {
    return this.snapshot
  }

  dispose() {
    this.transition(PLAYBACK_STATES.STOPPED)
    this.listeners.clear()
  }
}
