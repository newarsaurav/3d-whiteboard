/**
 * Three.js binding helpers for the Mike animation feature.
 *
 * The host still owns character loading, material tuning and grounding until
 * those pieces are extracted behind visual verification. This adapter only
 * standardizes how a scheduled command becomes a host playAsset() call.
 */

/**
 * @param {object} options
 * @param {(url: string, animationId: string, playOptions: object) => Promise<boolean>|boolean} options.playAsset
 * @param {(url: string, animationId: string, playOptions: object) => Promise<unknown>|unknown} [options.preloadAsset]
 * @param {{ warn?: Function }} [options.diagnostics]
 */
export function createThreeMikeExecutor({ playAsset, preloadAsset = null, diagnostics = console } = {}) {
  if (typeof playAsset !== 'function') {
    throw new TypeError('createThreeMikeExecutor requires playAsset(url, id, options)')
  }

  function resolveCommand(command) {
    const { record, posturePlan, options = {} } = command
    if (posturePlan?.warning) {
      diagnostics?.warn?.(`[animation:posture] ${posturePlan.warning}`)
    }

    const resolveAssetUrl =
      typeof options.resolveAssetUrl === 'function'
        ? options.resolveAssetUrl
        : (url) => url

    const url = resolveAssetUrl(record.mike_asset, record)
    return {
      url,
      id: record.id,
      playOptions: {
      repeats: options.repeats ?? record.default_repeats,
      loop: options.loop ?? record.loop_mode === 'repeat',
      fadeDuration: options.transitionSeconds ?? record.blend_in_seconds ?? 0.25,
      layer: options.layer ?? record.body_layer ?? 'full_body',
      },
    }
  }

  const executor = async function threeMikeExecutor(command, context = {}) {
    const resolved = resolveCommand(command)
    return playAsset(resolved.url, resolved.id, {
      ...resolved.playOptions,
      seamlessHandoff: Boolean(context.seamlessHandoff),
    })
  }
  if (typeof preloadAsset === 'function') {
    executor.prepare = async (command) => {
      const resolved = resolveCommand(command)
      return preloadAsset(resolved.url, resolved.id, resolved.playOptions)
    }
  }
  return executor
}
