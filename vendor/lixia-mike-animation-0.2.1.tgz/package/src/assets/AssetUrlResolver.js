const DEFAULT_CHARACTER_FILE = 'character/MIKE_RealLixia.glb'

function normalizeBaseUrl(value) {
  const base = String(value ?? '').trim()
  if (!base) throw new TypeError('Asset bundle baseUrl is required')
  return base.replace(/\/+$/, '')
}

function joinUrl(baseUrl, path) {
  return `${baseUrl}/${String(path).replace(/^\/+/, '')}`
}

function normalizedSourceId(record) {
  const sourceId = String(record?.source_id ?? '').trim()
  if (!sourceId || !/^\d+$/.test(sourceId)) {
    throw new TypeError(`Animation record has an invalid source_id: ${sourceId || '<empty>'}`)
  }
  return sourceId
}

/** Resolve the versioned `lixia-animation-assets/v1` deployment bundle. */
export function createVersionedAssetResolver({ baseUrl } = {}) {
  const normalizedBase = normalizeBaseUrl(baseUrl)

  function resolveAnimation(record) {
    const sourceId = normalizedSourceId(record)
    if (record.source_type === 'mixamo') {
      return joinUrl(normalizedBase, `animations/mixamo/${sourceId}_mike.fbx`)
    }
    if (record.source_type === 'seg_bvh' || record.source_type === 'seg') {
      return joinUrl(normalizedBase, `animations/seg/seg_${sourceId}_mike.fbx`)
    }
    throw new TypeError(`Unsupported animation source_type: ${record.source_type}`)
  }

  return Object.freeze({
    baseUrl: normalizedBase,
    characterUrl: joinUrl(normalizedBase, DEFAULT_CHARACTER_FILE),
    manifestUrl: joinUrl(normalizedBase, 'manifests/animations.json'),
    resolveAnimation,
  })
}

export { DEFAULT_CHARACTER_FILE }
