import postureDocument from '../../config/postures.json' with { type: 'json' }
import transitionDocument from '../../registry/transitions.json' with { type: 'json' }
import policy from '../../config/animation-policy.json' with { type: 'json' }

export class PostureSchedulerError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'PostureSchedulerError'
    this.code = code
    this.details = details
  }
}

export class PostureScheduler {
  constructor({
    registry,
    postures = postureDocument,
    transitions = transitionDocument,
    mode = policy.scheduler.posture_enforcement,
  }) {
    if (!registry) throw new TypeError('PostureScheduler requires an animation registry')
    if (!['observe', 'enforce'].includes(mode)) throw new TypeError(`Unknown posture mode: ${mode}`)

    this.registry = registry
    this.mode = mode
    this.validPostures = new Set(postures.postures.map((posture) => posture.id))
    this.transitions = transitions.transitions ?? []
    this.listeners = new Set()
    this.sequence = 0
    this.snapshot = Object.freeze({
      current_posture: postures.default_posture,
      phase: 'stable',
      active_animation_id: null,
      expected_end_posture: null,
      warning: null,
      sequence: this.sequence,
    })
  }

  plan(recordOrId) {
    const record = typeof recordOrId === 'string'
      ? this.registry.playable(recordOrId)
      : recordOrId
    this.#validateRecord(record)

    const from = this.snapshot.current_posture
    const to = record.starting_posture
    if (from === to) {
      return Object.freeze({
        allowed: true,
        mode: 'direct',
        from_posture: from,
        required_posture: to,
        transition_animation_id: null,
        animation_id: record.id,
        warning: null,
      })
    }

    const transition = this.transitions.find((item) =>
      item.enabled !== false && item.from_posture === from && item.to_posture === to,
    )
    if (transition) {
      return Object.freeze({
        allowed: true,
        mode: 'transition_then_play',
        from_posture: from,
        required_posture: to,
        transition_animation_id: transition.animation_id,
        animation_id: record.id,
        warning: null,
      })
    }

    const details = {
      animation_id: record.id,
      from_posture: from,
      required_posture: to,
    }
    if (this.mode === 'enforce') {
      throw new PostureSchedulerError(
        'POSTURE_TRANSITION_UNAVAILABLE',
        `No approved transition from ${from} to ${to}`,
        details,
      )
    }

    return Object.freeze({
      allowed: true,
      mode: 'direct_observed_mismatch',
      ...details,
      transition_animation_id: null,
      warning: `No approved transition from ${from} to ${to}; playback allowed in observation mode`,
    })
  }

  handlePlaybackEvent(event) {
    if (!event?.state) return this.snapshot
    if (event.layer && event.layer !== 'full_body' && event.layer !== 'locomotion') {
      return this.snapshot
    }
    const record = event.animation_id ? this.registry.resolve(event.animation_id) : null

    if (event.state === 'playing' && record) {
      const mismatch = this.snapshot.current_posture !== record.starting_posture
      return this.#publish({
        current_posture: this.snapshot.current_posture,
        phase: 'playing',
        active_animation_id: record.id,
        expected_end_posture: record.ending_posture,
        warning: mismatch
          ? `Playing ${record.id} expects ${record.starting_posture}, current posture is ${this.snapshot.current_posture}`
          : null,
      })
    }

    if (event.state === 'completed' && record) {
      return this.#publish({
        current_posture: record.ending_posture,
        phase: 'stable',
        active_animation_id: null,
        expected_end_posture: null,
        warning: null,
      })
    }

    if (event.state === 'idle' && policy.scheduler.reset_to_standing_on_idle) {
      return this.#publish({
        current_posture: postureDocument.default_posture,
        phase: 'stable',
        active_animation_id: null,
        expected_end_posture: null,
        warning: null,
      })
    }

    if (event.state === 'interrupted') {
      return this.#publish({
        ...this.snapshot,
        phase: 'interrupted',
        active_animation_id: null,
        expected_end_posture: null,
      })
    }

    if (event.state === 'error') {
      return this.#publish({ ...this.snapshot, phase: 'error', warning: event.message ?? event.error_code })
    }

    return this.snapshot
  }

  subscribe(listener, { emitCurrent = true } = {}) {
    if (typeof listener !== 'function') throw new TypeError('Posture listener must be a function')
    this.listeners.add(listener)
    if (emitCurrent) listener(this.snapshot)
    return () => this.listeners.delete(listener)
  }

  get current() {
    return this.snapshot
  }

  #validateRecord(record) {
    if (!record?.id) throw new PostureSchedulerError('INVALID_ANIMATION', 'Animation record is required')
    for (const field of ['starting_posture', 'ending_posture']) {
      if (!this.validPostures.has(record[field])) {
        throw new PostureSchedulerError(
          'UNKNOWN_POSTURE',
          `${record.id} has unknown ${field}: ${record[field]}`,
          { animation_id: record.id, field, value: record[field] },
        )
      }
    }
  }

  #publish(next) {
    this.sequence += 1
    this.snapshot = Object.freeze({ ...next, sequence: this.sequence })
    for (const listener of this.listeners) listener(this.snapshot)
    return this.snapshot
  }
}
