export class AnimationCommandSchedulerError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'AnimationCommandSchedulerError'
    this.code = code
    this.details = details
  }
}
export class AnimationCommandScheduler {
  constructor({
    registry,
    postureScheduler,
    lifecycle,
    executor,
    stopExecutor = null,
    maxQueue = 20,
  }) {
    if (!registry || !postureScheduler || !lifecycle || typeof executor !== 'function') {
      throw new TypeError('AnimationCommandScheduler requires registry, posture, lifecycle and executor')
    }
    this.registry = registry
    this.postureScheduler = postureScheduler
    this.lifecycle = lifecycle
    this.executor = executor
    this.stopExecutor = stopExecutor
    this.maxQueue = maxQueue
    this.sequence = 0
    this.current = null
    this.queue = []
    this.listeners = new Set()
    this.lifecycleUnsubscribe = lifecycle.subscribe(
      (event) => this.#handleLifecycle(event),
      { emitCurrent: false },
    )
  }

  async schedule(request) {
    const command = this.#normalize(request)
    if (!this.current) return this.#dispatch(command)

    const canPreempt =
      command.mode === 'replace' &&
      this.current.interruptible &&
      command.priority >= this.current.priority
    if (canPreempt) return this.#dispatch(command, { replaced: this.current })

    if (this.queue.length >= this.maxQueue) {
      throw new AnimationCommandSchedulerError(
        'SCHEDULER_QUEUE_FULL',
        `Animation queue limit of ${this.maxQueue} reached`,
      )
    }
    this.queue.push(command)
    this.#sortQueue()
    this.#publish('queued', command)
    if (typeof this.executor.prepare === 'function') {
      Promise.resolve(this.executor.prepare(command)).catch((error) => {
        this.#publish('prepare_error', command, { message: error.message })
      })
    }
    if (
      this.lifecycle.current?.state === 'transition_ready' &&
      this.lifecycle.current?.animation_id === this.current?.animationId
    ) {
      this.#beginHandoff()
    }
    return { accepted: true, queued: true, command_id: command.commandId }
  }

  cancel(commandId) {
    const index = this.queue.findIndex((command) => command.commandId === commandId)
    if (index < 0) return false
    const [cancelled] = this.queue.splice(index, 1)
    this.#publish('cancelled', cancelled)
    return true
  }

  clearPending(reason = 'cleared') {
    const removed = this.queue.splice(0)
    removed.forEach((command) => this.#publish('cancelled', command, { reason }))
    return removed.length
  }

  stop(reason = 'stopped') {
    const pendingRemoved = this.clearPending(reason)
    const stopped = this.current
    if (!stopped) return { current_stopped: false, pending_removed: pendingRemoved }

    this.current = null
    try {
      const result = this.stopExecutor?.(stopped, reason)
      if (result && typeof result.catch === 'function') {
        result.catch((error) => {
          this.#publish('stop_error', stopped, { reason, message: error.message })
        })
      }
    } catch (error) {
      this.#publish('stop_error', stopped, { reason, message: error.message })
    }
    this.lifecycle.transition?.('stopped', {
      animation_id: stopped.animationId,
      reason,
    })
    this.#publish('stopped', stopped, { reason })
    return { current_stopped: true, pending_removed: pendingRemoved }
  }

  subscribe(listener, { emitCurrent = true } = {}) {
    if (typeof listener !== 'function') throw new TypeError('Scheduler listener must be a function')
    this.listeners.add(listener)
    if (emitCurrent) listener(this.snapshot)
    return () => this.listeners.delete(listener)
  }

  get snapshot() {
    return Object.freeze({
      state: this.current ? 'busy' : 'ready',
      current: this.current ? { ...this.current } : null,
      pending: this.queue.map((command) => ({ ...command })),
    })
  }

  dispose() {
    this.lifecycleUnsubscribe?.()
    this.clearPending('disposed')
    this.current = null
    this.listeners.clear()
  }

  #normalize(request = {}) {
    const record = this.registry.playable(request.animationId)
    const priority = Number(request.priority ?? 50)
    if (!Number.isFinite(priority) || priority < 0 || priority > 100) {
      throw new AnimationCommandSchedulerError(
        'INVALID_PRIORITY',
        'Animation priority must be between 0 and 100',
      )
    }
    const mode = request.mode ?? 'replace'
    if (!['replace', 'enqueue'].includes(mode)) {
      throw new AnimationCommandSchedulerError('INVALID_MODE', `Unsupported schedule mode: ${mode}`)
    }
    const posturePlan = this.postureScheduler.plan(record)
    this.sequence += 1
    return Object.freeze({
      commandId: `animation-command-${this.sequence}`,
      sequence: this.sequence,
      animationId: record.id,
      record,
      posturePlan,
      priority,
      mode,
      interruptible: request.interruptible ?? record.interruptible ?? true,
      options: Object.freeze({ ...(request.options ?? {}) }),
    })
  }

  async #dispatch(command, { replaced = null, seamlessHandoff = false } = {}) {
    this.current = command
    if (replaced) this.#publish('preempted', replaced, { by_command_id: command.commandId })
    this.#publish('starting', command)
    try {
      const started = await this.executor(command, { seamlessHandoff })
      if (!started && this.current?.commandId === command.commandId) {
        this.current = null
        this.#publish('failed_to_start', command)
        void this.#drain()
      }
      return { accepted: Boolean(started), queued: false, command_id: command.commandId }
    } catch (error) {
      if (this.current?.commandId === command.commandId) this.current = null
      this.#publish('failed_to_start', command, { message: error.message })
      void this.#drain()
      throw error
    }
  }

  #handleLifecycle(event) {
    if (!this.current || event.animation_id !== this.current.animationId) return
    if (event.state === 'transition_ready') {
      if (this.queue.length) this.#beginHandoff()
      return
    }
    if (!['completed', 'error'].includes(event.state)) return
    const finished = this.current
    this.current = null
    this.#publish(event.state, finished)
    void this.#drain()
  }

  #beginHandoff() {
    if (!this.current || !this.queue.length) return
    const outgoing = this.current
    this.current = null
    this.#publish('handoff', outgoing, {
      next_command_id: this.queue[0]?.commandId ?? null,
    })
    void this.#drain({ seamlessHandoff: true })
  }

  async #drain({ seamlessHandoff = false } = {}) {
    if (this.current || !this.queue.length) return
    const next = this.queue.shift()
    await this.#dispatch(next, { seamlessHandoff })
  }

  #sortQueue() {
    this.queue.sort((left, right) =>
      right.priority - left.priority || left.sequence - right.sequence,
    )
  }

  #publish(type, command, detail = {}) {
    const event = Object.freeze({
      type,
      command_id: command?.commandId ?? null,
      animation_id: command?.animationId ?? null,
      priority: command?.priority ?? null,
      ...detail,
      snapshot: this.snapshot,
    })
    for (const listener of this.listeners) listener(event)
  }
}
