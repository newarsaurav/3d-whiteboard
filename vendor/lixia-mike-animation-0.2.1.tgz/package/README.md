# Mike Animation Layer

This folder owns animation metadata, validation and runtime playback policy for
Mike. The browser does not retarget animations. Every runtime asset must already
target the skeleton in `public/models/mike-from-blend/MIKE_RealLixia.glb`.

## Current foundation

- `FEATURE_IMPLEMENTATION_PLAN.md` defines the portable product API and phases.
- `package.json` exposes the installable `@lixia/mike-animation` package.
- `src/index.js` is the public import surface (`createMikeAnimationFeature`).
- `src/assets/AssetUrlResolver.js` maps the versioned Drive/CDN asset bundle.
- `src/core/` owns framework-neutral scheduling; `src/adapters/three/` binds Three.js.
- `config/mike-rig.json` freezes the production character contract.
- `config/animation-policy.json` defines runtime admission and cache policy.
- `registry/animations.json` is the source of truth for Mixamo and SeG assets.
- `src/registry/AnimationRegistry.js` resolves IDs and aliases.
- `src/player/AnimationClipCache.js` deduplicates FBX downloads and bounds memory.
- `scripts/audit-mike-rig.mjs` verifies Mike and refreshes the rig fingerprint.
- `scripts/build-animation-registry.mjs` regenerates registry metadata.
- `scripts/admit-all-seg-gestures.mjs` admits every SeG clip that passed automated QA.
- `src/director/PresentationTimeline.js` schedules a different deterministic gesture per spoken beat.
- `MOBILE_CORE_PACK.md` defines the 24-movement phone/offline bundle.
- `EMBODIED_BODY_ARCHITECTURE.md` defines body layers, safe world actions, and host boundaries.
- Finite queued clips preload and crossfade before the outgoing clip ends.
- Upper-body gestures use a separate filtered additive layer over base motion.

## Refresh the foundation

From the `lixia-movements` folder:

```powershell
node .\animation-layer\scripts\audit-mike-rig.mjs
node .\animation-layer\scripts\build-animation-registry.mjs
npm run animation:admit-all-seg
npm run animation:validate
```

Do not edit generated JSON by hand. Classification metadata should live in
reviewed inputs consumed by the registry builder.

## Run the application

```powershell
npm run dev
```

Open the local URL printed by Vite, normally `http://localhost:5173`. Open the
Settings panel to play Mike's demo animations. Chat additionally requires the
matcher in a second terminal:

```powershell
npm run matcher
```

The chat response now includes a beat timeline. The model returns short text +
gesture intents only; deterministic code resolves every intent to Mike assets:

```json
{
  "reply": "Welcome everyone. Let me explain the idea.",
  "gesture_timeline": [
    { "text": "Welcome everyone.", "gesture": "welcome", "animation_id": "seg_055", "offset_ms": 0 },
    { "text": "Let me explain the idea.", "gesture": "explain", "animation_id": "seg_377", "offset_ms": 1400 }
  ]
}
```

Offsets currently use speech-duration estimates. A TTS/lipsync integration can
drive exact boundaries instead: pass `{ autoAdvance: false }` to
`PresentationTimelinePlayer.play(timeline, onBeat, options)` so no estimate
timers are scheduled, then call `advanceTo(index)` from the TTS provider's
word/sentence boundary callbacks. Calling `advanceTo` during an auto-advancing
reply also cancels the remaining timers and hands control to the caller.

Gesture selection is semantic rather than limited to the original fixed intent
map. Each spoken beat supplies a short body-language query; the matcher searches
all 544 SeG records, filters recent clips, considers beat duration, and returns a
registry-validated Mike animation. Mixamo actions remain in a separate search
namespace.

## Integrate in another project

Install directly from this repository folder:

```powershell
npm install C:\path\to\lixia-movements\animation-layer
```

Point the feature at the extracted `lixia-animation-assets/v1` folder or its CDN
equivalent:

```js
import {
  createMikeAnimationFeature,
  createThreeMikeExecutor,
  createVersionedAssetResolver,
} from '@lixia/mike-animation'

const assets = createVersionedAssetResolver({
  baseUrl: 'https://cdn.example.com/lixia-animation-assets/v1',
})

// Load assets.characterUrl as Mike's GLB, then create the host mixer/player.
const feature = createMikeAnimationFeature({
  assetResolver: assets,
  executor: createThreeMikeExecutor({ playAsset }),
  stopExecutor: () => returnMikeToWaitingPose(),
})
```

`feature.stop()` clears queued commands, stops the active command through
`stopExecutor`, and lets the host return Mike to the waiting pose.

For world-aware behavior, wrap the feature with
`createEmbodiedActionController()`. It accepts a restricted action vocabulary
and delegates navigation to a validated host `worldExecutor`; see
`EMBODIED_BODY_ARCHITECTURE.md`.

## Verify the animation layer

```powershell
npm run animation:test
npm run animation:lint
npm run animation:validate
npm run animation:verify-build
npm run animation:package-check
```
