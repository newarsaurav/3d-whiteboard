# Mike Embodied Body Architecture

## Scope

This package owns Mike's body behavior. It does not generate speech, phonemes,
or facial performance. Those systems may connect through stable extension
ports, but they are implemented by other teams.

The body runtime must remain responsive when an AI service is slow or offline.
An AI/backend supplies permitted intentions; deterministic application code
validates targets, owns the world, and executes Mike's movement.

## Runtime flow

```text
backend plan
  -> embodied action controller
  -> permitted-action and target validation
  -> body-layer ownership
  -> animation scheduler / host world executor
  -> structured result returned to the planner
```

The backend must send registered animation IDs and named world targets. It must
not send FBX paths, bone rotations, unrestricted functions, or invented world
coordinates.

## Body layers

| Layer | Owner | Current implementation |
|---|---|---|
| `full_body` | Base pose and complete actions | Independent scheduler and playback queue |
| `locomotion` | Lower-body travel controlled by a world path | Contract and arbitration implemented; host navigation required |
| `upper_body` | Conversational and pointing gestures | Independent scheduler, filtered CC upper-body tracks, additive overlay |
| `gaze` | Head/eye attention | Target contract and arbitration implemented; bone driver is a host extension |
| `face` | Expression and lipsync | Reserved extension channel only; outside this package's implementation scope |

`full_body`/`locomotion` form the base motion. `upper_body`, `gaze`, and the
external face provider may operate concurrently. Two behaviors cannot own the
same layer. A locked high-priority locomotion behavior also blocks an
incompatible replacement base action.

Upper-body gestures are converted to additive deltas from their first frame.
Only spine, neck/head, clavicle, arm, hand, and finger tracks are retained. Leg
and root tracks are removed, so a gesture cannot move Mike's feet or replace a
walk cycle.

## Seamless clip handoff

The outgoing clip is not allowed to finish and pause before the next clip
starts. Finite playback opens a `transition_ready` window before the end:

```text
outgoing clip  |---------------------------|
incoming clip                         |---------------------------|
crossfade                              <----->
```

The default overlap is the incoming clip's transition duration, normally
`0.25` seconds. Queued assets begin preloading when admitted to the scheduler.
At `transition_ready`, the next command starts while the outgoing pose is still
active and Three.js crossfades between them. If no next upper-body gesture is
queued, the additive overlay fades out and exposes the still-running base pose.

Hosts must advance the feature and playback queues once per render frame. The
included viewer already does this.

## Permitted embodied actions

`createEmbodiedActionController()` accepts only:

```text
play_animation, gesture, idle, stop,
walk_to, turn_to, look_at, point_to, follow_user
```

Example:

```js
import {
  createEmbodiedActionController,
  createMikeAnimationFeature,
} from '@lixia/mike-animation'

const actions = createEmbodiedActionController({
  animationFeature: mike,
  validateWorldAction: (action) => world.canExecute(action),
  worldExecutor: (action) => world.execute(action),
})

const result = await actions.execute({
  type: 'walk_to',
  target: 'quiet_garden_entrance',
  priority: 60,
})
```

Initial results use `started`, `accepted`, or `failed`. The host finishes an
asynchronous action with:

```js
actions.complete(result.action_id, 'succeeded')
// also: failed | interrupted | cancelled
```

World actions must pass `validateWorldAction` before reaching `worldExecutor`.
A missing world executor fails safely rather than pretending that Mike moved.

## Responsibility boundaries

### Backend / planner

- Produces a short plan using only the permitted action vocabulary.
- Uses registered animation IDs or semantic intentions resolved by the director.
- Repairs plans after failed or interrupted results.
- Never controls bones or asset paths.

### Host world engine

- Owns perception, navigation, collision, reachable targets, and object metadata.
- Validates `walk_to`, `turn_to`, `point_to`, and `follow_user` targets.
- Advances the character root along a navigation path.
- Reports success, failure, interruption, or cancellation.

### Mike animation package

- Resolves and admits Mike animation IDs.
- Preloads, schedules, blends, interrupts, and caches clips.
- Owns deterministic body-layer arbitration.
- Keeps grounding and finger correction intact.
- Exposes gaze and face/lipsync ports without implementing those external systems.

## Remaining body work

1. Connect `locomotion` to a real host navigation/path callback and demonstrate
   Mike walking across a bounded world route.
2. Implement the smoothed neck/head gaze driver behind the existing target port.
3. Add interruption/recovery integration tests using a host world stub.
4. Visually QA additive upper-body gestures over idle and walking, then tune
   per-gesture overlay weights where necessary.
5. Connect presentation timelines to the embodied-action controller rather than
   calling viewer helpers directly.

Speech generation, TTS timing, phoneme analysis, and facial performance are not
items in this package's body implementation backlog.

