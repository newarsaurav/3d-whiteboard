# Mike Mobile Core Pack

## Purpose

The mobile core pack is the small subset stored on every user's phone. It gives
Mike instant startup, essential conversation, and graceful offline behavior.
The full 2,633-clip library remains remote and is downloaded/cached on demand.

This is separate from the future presentation-mode pack. Some movements may
overlap, but presentation mode will add more varied, sentence-timed gestures.

## Contents

- canonical `MIKE_RealLixia.glb`
- 7 approved Mixamo actions
- 17 approved SeG conversational gestures
- `mobile-core.json` with intents, sizes, hashes and local paths
- a 24-record `animations.json` subset

The selection source is `config/mobile-core.json`. Every item must already be
enabled and have `quality_status: approved` in the full registry.

## Mobile behavior

1. Install or download this pack during app installation/onboarding.
2. Verify file hashes from `manifests/mobile-core.json`.
3. Resolve these 24 IDs from device storage first.
4. If an ID is absent locally, request it from the full CDN library.
5. Cache downloaded remote clips using the application's LRU/storage policy.
6. Always keep `mixamo_1094` locally as the offline fallback.

The backend returns animation IDs, not phone paths. The mobile client owns the
mapping from `local_asset` to its sandbox/file URI.

```text
backend timeline → animation_id
  → mobile manifest contains ID? → play local file
  → otherwise                   → fetch CDN file, cache, play
  → fetch fails                 → play mixamo_1094
```

## Build and validate

From the repository root:

```powershell
npm run animation:validate-mobile-core
npm run animation:build-mobile-core -- --output E:\path\to\staging
```

The builder refuses missing, disabled, or non-approved movements.
